package edu.upf.dtic.classes;

public class Global {
	public static final String PRAAT_LOCATION = "/usr/local/bin/praat-master";
}
